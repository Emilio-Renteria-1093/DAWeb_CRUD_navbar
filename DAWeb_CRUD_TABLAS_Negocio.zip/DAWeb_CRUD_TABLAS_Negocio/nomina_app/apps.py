from django.apps import AppConfig


class NominaAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nomina_app'
