from django.apps import AppConfig


class ProductosAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'productos_app'
